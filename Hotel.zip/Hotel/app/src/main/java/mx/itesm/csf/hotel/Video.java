package mx.itesm.csf.hotel;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.Random;


public class Video extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = this;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//funcion para volver el telefono
        String[] array = context.getResources().getStringArray(R.array.videos);//metemos los urls de la aplicacion en un arreglo
        String randomvideo = array[new Random().nextInt(array.length)];//hacemos un random en el arreglo
        try{
            VideoView muestraVideo = new VideoView(this);
            setContentView(muestraVideo);//mostramos el video en un view video
            Uri video = Uri.parse(randomvideo);// parseasmo la url del ubiquitous
            muestraVideo.setVideoURI(video);

            muestraVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    otraActividad();//hasta que acabe nos manda a la actividad princiapl
                }
            });
            muestraVideo.start();
        }catch (Exception ex){
            otraActividad();
        }

    }

    private void otraActividad(){
        if(isFinishing())
            return;
        startActivity(new Intent(this,LayoutMainActivity.class));//nos manda a la actividad principal
        finish();
    }
}
