package mx.itesm.csf.hotel;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.PercentFormatter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class graficas extends AppCompatActivity {
    ArrayList<Entry> NoOfEmp;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_graficas);
        pd = new ProgressDialog(graficas.this);
        pd.setMessage("loading");
        NoOfEmp = new ArrayList();
        setTitle("PieChartActivity");
        cargar_datos();

    }
    public void cargar_datos() {
        pd.show();
        String url = "http://ubiquitous.csf.itesm.mx/~pddm-1023351/content/proyecto/v1/numberUsers.php";//url para el servicio del json


        StringRequest stringRequest = new StringRequest(Request.Method.POST,//metodo post
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("string", response);

                        try {
                            JSONObject obj = new JSONObject(response);

                            int num = obj.getInt("total");//obtenemos el valor total de los usuario
                            int max = obj.getInt("max");//obtenemos el valor max de los huespedes
                            NoOfEmp.add(new Entry(Float.valueOf(num), 0));
                            NoOfEmp.add(new Entry(Float.valueOf(max), 1));


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        PieChart pieChart = findViewById(R.id.piechart);

                        PieDataSet dataSet = new PieDataSet(NoOfEmp, "Nº HUESPEDES");//metemos los valores a la grafica
                        //tamaño de los esapcios y del texto
                        dataSet.setSliceSpace(2);
                        dataSet.setValueTextSize(20);

                        ArrayList year = new ArrayList();//ponemos las opciones en la grafica
                        year.add("LLENO");
                        year.add("VACIO");

                        PieData data = new PieData(year, dataSet);//memtemos los datos
                        pieChart.setData(data);
                        data.setValueFormatter(new PercentFormatter());
                        pieChart.setDescription("Esta grafica representa la opucacion del hotel");//descripscion de la grafica

                        ArrayList<Integer> colors = new ArrayList<>();//colores para cada parte
                        colors.add(Color.RED);
                        colors.add(Color.GRAY);
                        dataSet.setColors(colors);
                        pieChart.animateXY(5000, 5000);//animacion
                        pd.hide();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error != null) {

                            Toast.makeText(getApplicationContext(), "NO SE RECIVIO JSON", Toast.LENGTH_LONG).show();//mensaje de error
                            pd.hide();
                        }
                    }
                }

        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);

    }
}