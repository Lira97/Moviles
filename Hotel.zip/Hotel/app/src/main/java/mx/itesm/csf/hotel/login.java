package mx.itesm.csf.hotel;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class login extends AppCompatActivity {
    AdaptadorDB adaptador = new AdaptadorDB(this);//cresmo un objeto de la clase adaptador para la base de datos SQlite
    private EditText editTextUsername, editTextPassword;//instanciamos un edittext
    private Button buttonLogin;//instanciamos un boton
    private ProgressDialog progressDialog;//instanciamos un Dialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login);
        adaptador.open();//abrimos la base de datos
        if( adaptador.obtenTodosLosClientes() !=null && adaptador.obtenTodosLosClientes().getCount()>0)//si encuetra un cliente en la base
        {
            adaptador.close();//cierra la base
            startActivity(new Intent(this, LayoutMainActivity.class));//nos regresa a la actividad principal
            return;
        }
        editTextUsername = (EditText) findViewById(R.id.editTextUsername);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        buttonLogin = (Button) findViewById(R.id.buttonLogin);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");


    }
    private void userLogin(){
        final String username = editTextUsername.getText().toString().trim();//guardamos el correo en  username
        final String password = editTextPassword.getText().toString().trim();//guardamos la password en password

        progressDialog.show();//mostramos un barra de carga

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,//mandamos el tipo de request y
                Constants.URL_LOGIN,//                              la url
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);//recibimos un json request
                            if(!obj.getBoolean("error"))//sie es un error y se sale del loop
                            {
                                adaptador.open();
                                long id = adaptador.insertaClientes(//insertamos los datos del json a la base de datos
                                        obj.getString("nombre"),//mapeamos el nombre en el json
                                        obj.getString("correoElectronico")//mapeamos el correoelectronico
                                );
                                adaptador.close();//cerramos la base
                                startActivity(new Intent(getApplicationContext(), LayoutMainActivity.class));//nos vamos a la actividad del video
                                finish();
                            }else{
                                Toast.makeText(//mensaje de error
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();

                        Toast.makeText(//mensaje de error
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("correoElectronico", username);//mandamos el correo
                params.put("contrasena", password);//mandamos la contraseña
                return params;
            }

        };

        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }

    public void onClicklogin(View view) {//funcion para el boton del login
        if(view == buttonLogin){
            userLogin();//llama a la funcion userlogin()
        }
    }
}

