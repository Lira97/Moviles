package mx.itesm.csf.hotel;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LayoutMainActivity extends AppCompatActivity {

    //URL JSOn
    private static final String URL_PRODUCTS = "http://ubiquitous.csf.itesm.mx/~pddm-1023351/content/proyecto/v1/userDevices.php";
    private Toolbar mTopToolbar;
    List<Product> productList;//lista de todos los productos
    AdaptadorDB adaptador = new AdaptadorDB(this);
    RecyclerView recyclerView;
    String correo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_main);

        //recyclerview del xml
        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //incializa el arreglo de los porductos
        productList = new ArrayList<>();

      //cargamos el json
        loadProducts();
        adaptador.open();
        Cursor c = adaptador.obtenTodosLosClientes();//obtemos todos los datos del cliente
        if (c.moveToFirst())
        {
            do {
                DespliegaCliente(c);//llamamos fucnion para almacenarlo
            } while (c.moveToNext());
        }
        adaptador.close();
        mTopToolbar = (Toolbar) findViewById(R.id.my_toolbar);//toolbar para logout y graficas
        setSupportActionBar(mTopToolbar);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Manejar el elemento de la barra de acción aquí. La barra de acción
        // Manejar automáticamente los clics en el botón Inicio / Arriba, durante tanto tiempo.
        // a medida que especifique una actividad principal en AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_favorite)
        {
            adaptador.open();//borramos toda la base
            adaptador.borraTodo();
            adaptador.close();

            Intent actividad = new Intent(LayoutMainActivity.this,login.class);//inicialiazamos la actividad login
            startActivity(actividad);
        }
        if (id == R.id.graph)
        {
            Intent actividad = new Intent(LayoutMainActivity.this,graficas.class);//inicialiazamos la actividad graficas
            startActivity(actividad);
        }


        return super.onOptionsItemSelected(item);//
    }
    private void loadProducts() {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,//mandamos el tipo de request y
                URL_PRODUCTS,//  la url
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                                JSONArray array = new JSONArray(response);//recibimos un json request

                                 // atravesando todo el objeto
                                for (int i = 0; i < array.length(); i++) {

                                    // obtener objeto de producto de json array
                                    JSONObject product = array.getJSONObject(i);

                                    // añadiendo el producto a la lista de productos
                                    productList.add(new Product(
                                            product.getString("nombre"),
                                            product.getString("url")
                                    ));
                                }

                            // creando un objeto adaptador y configurándolo para recyclerview
                                ProductsAdapter adapter = new ProductsAdapter(LayoutMainActivity.this, productList);
                                recyclerView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("correoElectronico", correo);//mandamos el correo del cliente para obtener sus dispositivos

                return params;
            }

        };

        Volley.newRequestQueue(this).add(stringRequest);

    }
    public void DespliegaCliente(Cursor c)
    {
        correo=c.getString(1);

    }
}