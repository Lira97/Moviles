package mx.itesm.csf.hotel;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

//

public class AdaptadorDB {



    static final String  LLAVE_NOMBRE = "nombre";//llave para nombre
    static final String  LLAVE_CORREOELECTRONICO = "correoElectronico";//llave para correoelectronico
    static final String  LLAVE_APELLIDOPATERNO = "apellidoPaterno";//llave para appellidoPaterno
    static final String  LLAVE_APELLIDOMATERNO = "apellidoMaterno";//llave para apellidoMaterno
    static final String  LLAVE_TELEFONO = "telefono";//llave para telefono
    static final String  LLAVE_EMAIL = "email";//llave para mail
    static final String ETIQUETA = "AdaptadorDB";//llave para AdaptadorDB

    static final String NOMBRE_BD = "Clientes";
    static final String BD_TABLA = "clientes";
    static final int VERSION_DB = 2;

    static final String CREAR_BD =
            "create table clientes (idHuespedd integer primary key , " + "nombre text not null, correoElectronico text not null);";//cremos la base de datos
    final Context contexto;

    DatabaseHelper DBHelper;
    SQLiteDatabase db;

    public AdaptadorDB(Context ctx)
    {
        this.contexto = ctx;
        DBHelper = new DatabaseHelper(contexto);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context)
        {
            super(context, NOMBRE_BD, null, VERSION_DB);
        }

        @Override
        public void onCreate(SQLiteDatabase db)//fucnion para crear base de datos
        {
            try {
                db.execSQL(CREAR_BD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            Log.w(ETIQUETA, "Actualizando la version de la Base de Datos de " + oldVersion + " a "
                    + newVersion + ", este proceso eliminará los registros de la versión anterior");
            db.execSQL("DROP TABLE IF EXISTS clientes");
            onCreate(db);//funcion para actualizar base
        }
    }

    //--- Abrimos la BD ---

    public AdaptadorDB open() throws SQLException//abrimos la base de datos
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }

    //--- Cerramos la BD ---
    public void close()
    {
        DBHelper.close();
    }//cerramos la base

    //--- Insertamos registros a la tabla clientes ---
    public long insertaClientes(String nombre, String email )//insertamos elementos
    {
        ContentValues initialValues = new ContentValues();//cremos un contentedor
        initialValues.put(LLAVE_NOMBRE, nombre);//metemos el nombre
        initialValues.put(LLAVE_CORREOELECTRONICO, email);//metemos el mail
        return db.insert(BD_TABLA, null, initialValues);//inserta los valores en la tabla
    }

    public void borraTodo()
    {
        db.execSQL("delete from "+ BD_TABLA);
    }//borramos toda la tabla
    public boolean isLoggedIn()
    {
        if(obtenTodosLosClientes() != null)
        {
            return true;
        }
        return false;
    }

    //--- Recuperamos todos los registros de la tabla ---
    public Cursor obtenTodosLosClientes()
    {
        return db.query(BD_TABLA, new String[] { LLAVE_NOMBRE,
                LLAVE_CORREOELECTRONICO}, null, null, null, null, null);
    }
}
