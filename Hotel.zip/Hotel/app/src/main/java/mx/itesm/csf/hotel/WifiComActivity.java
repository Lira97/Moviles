package mx.itesm.csf.hotel;

import android.os.AsyncTask;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class WifiComActivity extends AsyncTask<Void,Void,Void> {

    Socket socket;
    public static String wifiModuleIp = "";//string para ip
    public static int wifiModulePort = 0;//string para el puerto
    String CMD ;
    public WifiComActivity(int wifiModulePort, String wifiModuleIp,String CMD)
    {
        this.wifiModuleIp = wifiModuleIp;//guardamos la ip
        this.wifiModulePort = wifiModulePort;//guardamos el purto
        this.CMD = CMD;//guardamos el mensaje

    }

    @Override
    protected Void doInBackground(Void... params){
        try{
            InetAddress inetAddress = InetAddress.getByName(wifiModuleIp);//obtenemos la ip adress
            socket = new Socket(inetAddress,wifiModulePort);//abrimos el socket
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());//guardamos la ip y el puerto
            dataOutputStream.writeUTF(CMD);//guardamos los valores ingresados
            dataOutputStream.close();
            socket.close();//cerramos el sokect
        }catch (UnknownHostException e){e.printStackTrace();}catch (IOException e){e.printStackTrace();}
        return null;
    }


}
