package mx.itesm.csf.hotel;

public class Constants {

    private static final String ROOT_URL = "http://ubiquitous.csf.itesm.mx/~pddm-1023351/content/proyecto/";//url para los servicios
    public static final String URL_LOGIN = ROOT_URL+"v1/userLogin.php";//url para login


}

