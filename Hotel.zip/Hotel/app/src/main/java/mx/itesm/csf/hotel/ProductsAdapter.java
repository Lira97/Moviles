package mx.itesm.csf.hotel;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.bumptech.glide.Glide;

import java.util.List;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ProductViewHolder> {
    String IP;
    int PORT;
    private Context mCtx;
    private List<Product> productList;

    public ProductsAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;//cremos una lista de productos
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.product_list, null);//ponemos la la lista en el flatter
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        final Product product = productList.get(position);//obtenemos la posicion de los productos

        //loading the image
        Glide.with(mCtx)
                .load(product.getImage())
                .into(holder.imageView);//sacamos las imagenes

        holder.textViewPrice.setText(String.valueOf(product.getPrice()));
        holder.toggleButton.setChecked(product.getSelected());//cremos un toggle botton
        holder.toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (product.getSelected()) {
                    product.setSelected(false);

                    sendWifiCmd("10.49.3.50",21568,"no"+ product.getPrice());//si esta apagado se pone en of si se manda señal
                } else {
                    product.setSelected(true);

                    sendWifiCmd("10.49.3.50",21568,"si"+ product.getPrice());//si esta prendida se pone en on y se amnda mensaje
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewPrice;
        ToggleButton toggleButton;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewPrice = itemView.findViewById(R.id.textViewPrice);//cremos un textview
            toggleButton = itemView.findViewById(R.id.toggleButton3);//cremos un toggle botton
            imageView = itemView.findViewById(R.id.imageView);//cremos un image view


        }
    }
    private void sendWifiCmd(String ipAddress, int ipPort, String CMD)
    {
        WifiComActivity wifi =new WifiComActivity(ipPort,ipAddress,CMD);//madamos los valores de la raspberry pi
        wifi.execute();
    }
}